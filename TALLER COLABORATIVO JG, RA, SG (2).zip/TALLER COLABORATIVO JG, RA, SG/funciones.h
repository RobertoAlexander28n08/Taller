
void mostrarProducto();
void mostrarDisponibilidad(int, int, int, int, int);
int leerEntero(const char*);
float leerFlotante(const char*);